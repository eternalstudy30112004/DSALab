#include <stdio.h>

int main(){
    int a = 10,b = 15;
    int largest;
    if (a > b)
        largest = a;
    else
        largest = b;
    return 0;
}