#include<stdio.h>
/*
 * print numbers from 10 to 1
*/

int main() {
    int i = 10 ;
    while ( i >= 1) {
        printf ( "%d\n", i ) ;
        i--;
    }
    return 0;
}
