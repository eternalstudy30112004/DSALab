#include<stdio.h>
/*
* print numbers from 1 to 10
*/

int main() {
    int i = 1 ;
    while (i <= 10) {
        printf ("%d\n", i ) ;
        i=i+1;
    }
    return 0;
}
