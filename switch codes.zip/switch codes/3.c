/*
File Name:
Author: Shrida Kalamkar

*/


#include <stdio.h>
int main() {
   int x = 10;
   switch (x)
   {
       case 1: printf("Choice is 1\n");
       case 2: printf("Choice is 2\n");
       case 3: printf("Choice is 3\n");
       case 4: printf("Choice is 4\n");
               break;
       //default: printf("other\n");
               // break;
   }
 //  printf("After Switch");
   return 0;
}

