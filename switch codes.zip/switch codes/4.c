/*
File Name:
Author: Shrida Kalamkar

*/


//Problem :

#include <stdio.h>
int main() {
   int x = 4;
   switch(x)
   {
       default: printf("Choice other than 1 and 2");

       case 1: printf("Choice is 1");
               break;
       case 2: printf("Choice is 2");
                break;
   }
   return 0;
}
