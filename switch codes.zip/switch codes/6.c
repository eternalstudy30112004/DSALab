/*
File Name:
Author: Shrida Kalamkar

*/

#include<stdio.h>

//Problem :

int main(){
	int i = 0 ;
	switch(i){
		case 0 :
			printf ( "\nCustomers are dicey" ) ;
		case 1 :
			printf ( "\nMarkets are pricey" ) ;
		case 2 :
			printf ( "\nInvestors are moody" ) ;
		case 3 :
			printf ( "\nAt least employees are good" ) ;
	}
	return 0;
}
